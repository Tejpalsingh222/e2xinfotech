import SignIn from "pages/LandingPages/SignIn";

export default function SignInPage() {
  return <SignIn />;
}
