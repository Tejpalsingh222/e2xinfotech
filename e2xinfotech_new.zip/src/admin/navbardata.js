import React, { useEffect, useState } from 'react';
export const userColumns = [
    // { field: "id", headerName: "id", width: 70 },
    {
        field: "page_name",
        headerName: "Page_Name",
        width: 230,
      },
   
    {
      field: "routes",
      headerName: "Routes",
      width: 200,
    },
    
    {
      field: "page_link",
      headerName: "Page_Link",
      width: 200,
    },
  ];
  
  
  //temporary data
  
   


