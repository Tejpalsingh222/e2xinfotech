import React  from "react";

function Dashboard() {
    return(
        <div className="div">
           <li>About us</li>
        </div>
    );
    
}
export default Dashboard;