import styled from "styled-components";

export const EditorContainer = styled.div``;
export const Controls = styled.div``;
export const CodingSection = styled.div``;