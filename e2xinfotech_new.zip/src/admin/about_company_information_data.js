import React, { useEffect, useState } from 'react';
export const userColumns = [
    // { field: "id", headerName: "id", width: 70 },
    {
        field: "title",
        headerName: "Title",
        width: 230,
      },
    
    {
      field: "description",
      headerName: "Description",
      width: 200,
    },
    
      {
        field: "icons",
        headerName: "Icons",
        width: 200,
      },
      
  ];
  
   


