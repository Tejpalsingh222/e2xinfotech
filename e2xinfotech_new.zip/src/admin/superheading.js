import React, { useEffect, useState } from 'react';
export const userColumns = [
    // { field: "id", headerName: "id", width: 70 },
    {
        field: "page_heading",
        headerName: "Page_Heading",
        width: 230,
      },
   
    {
      field: "page_paragraph",
      headerName: "Page_Paragraph",
      width: 200,
    },

    {
      field: "page_link",
      headerName: "Page_Link",
      width: 200,
    },
  ];
  
  
  //temporary data
  
   


