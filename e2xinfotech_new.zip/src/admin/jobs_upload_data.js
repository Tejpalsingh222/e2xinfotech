import React, { useEffect, useState } from 'react';
export const userColumns = [
    // { field: "id", headerName: "id", width: 70 },
    {
      field: "title",
      headerName: "Title",
      width: 200,
    },
    {
        field: "about_company",
        headerName: "Aboutcompany",
        width: 200,
      },

      {
        field: "jobtitle",
        headerName: "JobTitle",
        width: 200,
      },
      // {
      //   field: "para",
      //   headerName: "Paragraph",
      //   width: 200,
      // },
      {
        field: "joblocation",
        headerName: "Job Location",
        width: 200,
      },
      {
        field: "date",
        headerName: "Posted Date",
        width: 200,
      },


    {
      field: "job_description",
      headerName: "Job Description",
      width: 200,
    },
      {
        field: "open_positions",
        headerName: "Open Positions",
        width: 30,
      },
      {
        field: "skills_required",
        headerName: "Skills Required",
        width: 200,
      },
      {
        field: "education",
        headerName: "Education",
        width: 100,
      },
      {
        field: "desirable_skills",
        headerName: "Desirable Skills",
        width: 200,
      },
      {
        field: "experience",
        headerName: "Experience",
        width: 20,
      },
      
  ];
  
   


